import{r as o}from"./vendor-react-BRowJHOY.js";const s=()=>{o.useEffect(()=>{window.scrollTo({top:0,behavior:"smooth"})},[])};export{s as u};
